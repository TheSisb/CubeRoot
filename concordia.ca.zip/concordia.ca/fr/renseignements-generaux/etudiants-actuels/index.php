<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en"><!-- InstanceBegin template="/Templates/insidepage_xml.dwt.php" codeOutsideHTMLIsLocked="true" -->
<head>
<!-- Template System Version 1.7.3 - any questions should be directed to Sothea Nim, snim@alcor.concordia.ca -->
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="verify-v1" content="knGpcn5wDEFQ5p/n0gKYttiwWSEJ7At+hfca0wnlyTY=" />
<meta name="google-site-verification" content="IfmepecIw8J0xEUuoCT__X7Onfbv9EavyLM_HS1ORVo" />
<title>&Eacute;tudiants actuels - Universit&eacute; Concordia - Montr&eacute;al, Qu&eacute;bec, Canada</title>
<link rel="shortcut icon" href="http://globalmk.concordia.ca/favicon.ico" type="image/x-icon" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="owner" content="Universit&eacute; Concordia" />
<meta name="author" content="Concordia University" />
<meta name="copyright" content="Concordia University" />
<meta name="robots" content="all,index" />
<meta name="resource-type" content="document" />
<meta name="distribution" content="global" />
<meta name="rating" content="general" />
<meta name="language" content="en-ca" />
<link type="text/css" href="http://www.concordia.ca/globalmk/style.php?owner=mainsite" rel="stylesheet" media="screen, projection" charset="utf-8" />
<style type="text/css">
<!--
		#homebutton a{ position:relative;display:block;background:url(../../custom/images/concordiauniversitylogo.gif) no-repeat 0px -3px;width:327px;height:120px;text-indent:-9999px; }
	#concordialogo{ margin:0;padding:0;position:static; }
	-->
</style>
<link type="text/css" href="http://www.concordia.ca/fr/custom/stylesheets/custom.php?home=0&browser=firefox&v=&lang=fr" rel="stylesheet" media="all" charset="utf-8" />
<link type="text/css" href="http://www.concordia.ca/fr/stylesheets/m.css" rel="stylesheet" media="all" charset="utf-8" />
<link type="text/css" href="http://www.concordia.ca/fr/stylesheets/l.css" rel="alternate" media="" charset="utf-8" />
<link type="text/css" href="http://www.concordia.ca/fr/stylesheets/xl.css" rel="alternate" media="" charset="utf-8" />
<!--[if IE]>
<link type="text/css" href="/globalmk/style.php?browser=ie&amp;version=" rel="stylesheet" media="all" charset="utf-8" />
<![endif]--><script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
<script type="text/javascript" src="http://www.concordia.ca/fr/custom/javascripts/js.php?owner=mainsite"></script>
<script type="text/javascript">
secure_suffix = "";
domain = "www.concordia.ca";
siteroot = "/fr/";
relative_path = "../../";
data_path = "../../custom/";
pagetitle="&Eacute;tudiants actuels";
uri = "/fr/renseignements-generaux/etudiants-actuels/";
member = 1;
</script>
<!--<script type="text/javascript" src="http://w.sharethis.com/button/buttons.js"></script><script type="text/javascript">stLight.options({publisher:'fafdea98-7556-4637-8177-9efd9fe1c1e6'});</script>-->
</head>

<body id="body_li_etudiants-actuels_2" class="li_mainmenu_renseignements-generaux_1 li_submenu_etudiants-actuels_2" >
<!-- Contribute/DW Template System Version 1.7.3 or help contact Sothea Nim (snim@alcor.concordia.ca) -->
<div id="top">&nbsp;</div>
<div id="globaltools_wrapper">
  <div id="globaltools">
  	 		<div class="leftcol">
			<h3 class="hide">Breadcrumb</h3>	  
      <ul class="globalbreadcrumb">
        <li><a href="../../index.html" accesskey="h" role="backhome">Universit&eacute; Concordia</a></li>
	  	</ul>
	  </div>
		    <div class="rightcol">
      <h2 class="hide">Accessibility Tools</h2>
      <ul class="accesstools">
        <!--<li><a href="#maincontent" accesskey="s">Passer au contenu</a></li>
        <li><a href="/fr/accessibility.php"  accesskey="0">Accessibilit&eacute;</a></li>
        <li id="textsize_li">Taille du texte:  <span id="textsizetools"><a href="../../accessibility.php#textsize_faq">N/A</a></span></li>-->
        <li><a href="http://www.myconcordia.ca" title="Sign in">MyConcordia</a>&nbsp;&nbsp;&nbsp;<a href="../../../about/contact/" title="Department, faculty or staff">Contactez-nous</a>&nbsp;&nbsp;&nbsp;<a href="../../../about/contact/campus-map/index.html" title="Getting around">Plan du campus</a>&nbsp;
        </li>
				
				<li><a href="../../../index.html" class="otherurl">English</a></li>
      </ul>
		</div>
	  <div class="clear">&nbsp;</div>
	</div>
</div>
<div id="emergency_alert">&nbsp;</div><div id="page">
	<!-- page_inner_wrapper start -->
<div id="page_inner_wrapper">

<div id="banner">
	<div id="homebutton">
			<a href="../../index.html" accesskey="1" title="Universit� Concordia">Universit&eacute; Concordia</a>
		</div>
	<h3 class="hide">Search</h3>
<div id="search" class="search">
		<div id="conuni_top_searchpanel">
		<ul class="search-tabs">
			<li><a href="../../../../websitewww.google.ca/search_hl_en_q_site_3Ahttp_3A_2F_2Fwww.concordia.ca_btnG_Search_meta_" id="entire" title="Tout Concordia">Tout Concordia</a></li>
			<li><a href="../../../index.html" id="directory" title="R�pertoire">R&eacute;pertoire</a></li>
			<!--<li><a href="http://news.concordia.ca/" id="newsandevents" title=""></a></li>-->
		</ul>
		<!-- tab "panes" -->
		<div class="search-panes">
			<form name="conuni_search" id="conuni_search" action="http://www.concordia.ca/fr/renseignements-generaux/etudiants-actuels/#" method="post">
			<input type="text" name="query" id="query" class="search_field" value="" />
			<input type="submit" name="conuni_search_button" id="conuni_search_button" class="search_button" value="Recherche" />
			<input type="hidden" name="ga" id="cx" value="004300337896495107326:jx239fs85pg" />
			</form>
		</div>
		<div id="suggest_hint">&nbsp;</div>
	</div>
</div><div class="clear">&nbsp;</div><h2 class="hide">Main Menu</h2>
<div id="mainmenu">
<ul class="themainmenu"> <li id="li_mainmenu_renseignements-generaux_1" class="active">
<a class="li_mainmenu_renseignements-generaux_1_a" href="../index.html">
Renseignements<br />g&eacute;n&eacute;raux </a>
</li>
<li id="li_mainmenu_concordia-en-bref_1" >
<a class="li_mainmenu_concordia-en-bref_1_a" href="../../concordia-en-bref/index.html">
Concordia en<br />bref </a>
</li>
<li id="li_mainmenu_enseignement-et-recherche_1" >
<a class="li_mainmenu_enseignement-et-recherche_1_a" href="../../enseignement-et-recherche/index.html">
Enseignement et<br />recherche </a>
</li>
<li id="li_mainmenu_nouvelles-et-evenements_1" >
<a class="li_mainmenu_nouvelles-et-evenements_1_a" href="../../nouvelles-et-evenements/index.html">
Nouvelles et<br />&eacute;v&eacute;nements </a>
</li></ul>
</div></div>
<div class="clear">&nbsp;</div>	<h2 class="hide">Renseignements généraux</h2>
<div class="submenu">
<ul id="ul_renseignements-generaux"> <li id="li_submenu_futurs-etudiants_2" >
<a class="li_submenu_futurs-etudiants_2_a" href="../futurs-etudiants/">
Futurs &eacute;tudiants </a>
</li>
<li id="li_submenu_etudiants-actuels_2" class="active">
<strong>&Eacute;tudiants<br />actuels </strong></li>
<li id="li_submenu_corps-professoral-et-personnel_2" >
<a class="li_submenu_corps-professoral-et-personnel_2_a" href="http://www.concordia.ca/fr/renseignements-generaux/corps-professoral-et-personnel/">
Corps professoral<br />et personnel </a>
</li>
<li id="li_submenu_diplomes-et-amis_2" >
<a class="li_submenu_diplomes-et-amis_2_a" href="http://www.concordia.ca/fr/renseignements-generaux/diplomes-et-amis/">
Dipl&ocirc;m&eacute;s<br />et amis </a>
</li>
</ul>
</div>
	<div id="maincontent"  class="topgutter"  >
		<div id="lh_menu_area">
		<div id="lh_menu">
<ul class="level_3">
<li id="li_services-aux-nouveaux-etudiants_3"> <a class="li_services-aux-nouveaux-etudiants_3_a" href="services-aux-nouveaux-etudiants/index.html">
Services aux<br />nouveaux &eacute;tudiants </a>
</li>
<li id="li_consultation-pedagogique_3"> <a class="li_consultation-pedagogique_3_a" href="consultation-pedagogique/">
Consultation<br />p&eacute;dagogique </a>
 </li>
<li id="li_services-aux-etudiants_3"> <a class="li_services-aux-etudiants_3_a" href="services-aux-etudiants/index.html">
Services aux<br />&eacute;tudiants </a>
</li>
<li id="li_associations-etudiantes_3"> <a class="li_associations-etudiantes_3_a" href="http://www.concordia.ca/fr/renseignements-generaux/etudiants-actuels/associations-etudiantes/">
Associations<br />&eacute;tudiantes </a>
</li>
<li id="li_ressources-generales_3"> <a class="li_ressources-generales_3_a" href="http://www.concordia.ca/fr/renseignements-generaux/etudiants-actuels/ressources-generales/">
Ressources<br />g&eacute;n&eacute;rales </a>
</li>
<li id="li_bureaux-administratifs_3"> <a class="li_bureaux-administratifs_3_a" href="http://www.concordia.ca/fr/renseignements-generaux/etudiants-actuels/bureaux-administratifs/">
Bureaux administratifs </a>
</li>
<li id="li_diplome-et-gestion-de-carriere_3"> <a class="li_diplome-et-gestion-de-carriere_3_a" href="diplome-et-gestion-de-carriere/index.html">
Dipl&ocirc;me et<br />gestion de carri&egrave;re </a>
</li>
<li id="li_conseiller-en-ligne_3"> <a class="li_conseiller-en-ligne_3_a" href="http://www.concordia.ca/resources/academic/ask/">
Conseiller en<br />ligne (en anglais)</a>
</li>
<li id="li_probite-intellectuelle_3"> <a class="li_probite-intellectuelle_3_a" href="probite-intellectuelle/index.html">
Probit&eacute;<br />intellectuelle </a>
</li>
</ul>
</div>&nbsp;
	</div>
		<div class="insidecontent  twothirds">

			<p class="breadcrumb"><a href="../../index.html">Universit&eacute; Concordia</a> &gt; <a href="../index.php">Renseignements g&eacute;n&eacute;raux</a> &gt; </p>
			<h1>&Eacute;tudiants actuels</h1>
	<div class="page-title-hline">&nbsp;</div>
	










<!-- MAIN CONTENT AREA - START -->


			<div class="contentcolumn">
				<br class="hide" />
<!-- InstanceBeginEditable name="maincontent" --><!-- FCKEDITOR_maincontent --><!-- /FCKEDITOR_maincontent --> <!-- InstanceEndEditable -->

<!-- InstanceBeginEditable name="MainContent" -->
<div class="dropshadow wide"><img class="framed" src="http://www.concordia.ca/images/information-for-you/current-students/header_currentStudents.jpg" alt="Current students" width="470" height="154" /></div>


  <h2><a href="services-aux-nouveaux-etudiants/index.html">Services aux nouveaux &eacute;tudiants</a></h2>
  <p>Concordia vous offre une grande vari&eacute;t&eacute; de services ainsi que de nombreuses activit&eacute;s et s&eacute;ances d&rsquo;information-for-yourmation afin de vous familiariser avec l&rsquo;Universit&eacute; et de vous guider tout au long de votre premi&egrave;re ann&eacute;e d&rsquo;&eacute;tudes. 
    En savoir plus sur les services aux nouveaux &eacute;tudiants.</p>
        <h2><a href="consultation-pedagogique/">Consultation p&eacute;dagogique</a></h2>
    <p>D&eacute;sorient&eacute; &agrave; propos des exigences universitaires ou du processus d&rsquo;inscription? Conseils p&eacute;dagogiques, information-for-yourmations sur les inscriptions et les r&eacute;admissions : les services Gestion des effectifs &eacute;tudiants, Consultation et orientation ainsi que les facult&eacute;s peuvent vous aider! 
    En savoir plus sur la consultation p&eacute;dagogique. </p>
        <h2><a href="services-aux-etudiants/index.html">Services aux &eacute;tudiants</a></h2>
    <p>Besoin d&rsquo;aide? Services de consultation, information-for-yourmations sur les pr&ecirc;ts et bourses&hellip; 
    En savoir plus sur les services aux &eacute;tudiants. </p>
        <h2><a href="http://www.concordia.ca/fr/renseignements-generaux/etudiants-actuels/associations-etudiantes/">Associations &eacute;tudiantes</a></h2>
    <p>Qui dit universit&eacute; dit associations &eacute;tudiantes. Profitez au maximum de votre exp&eacute;rience &agrave; Concordia en prenant part aux nombreuses associations &eacute;tudiantes, dont la grande vari&eacute;t&eacute; contribue grandement &agrave; enrichir la vie sur le campus. </p>
        <h2><a href="http://www.concordia.ca/fr/renseignements-generaux/etudiants-actuels/ressources-generales/">Ressources &agrave; votre disposition</a></h2>
    <p>D&eacute;couvrez tout ce que vous offre Concordia sur ses deux campus : loisirs et sports, biblioth&egrave;ques, service de navettes&hellip; 
    En savoir plus sur les ressources &agrave; votre disposition. </p>
        <h2><a href="http://www.concordia.ca/fr/renseignements-generaux/etudiants-actuels/bureaux-administratifs/">Bureaux administratifs </a></h2>
    <p>Aux prises avec les proc&eacute;dures administratives? Vous cherchez qui contacter? 
    En savoir plus sur les bureaux administratifs. </p>
        <h2><a href="diplome-et-gestion-de-carriere/index.html">Dipl&ocirc;me et gestion de carri&egrave;re</a></h2>
    <p>Bient&ocirc;t dipl&ocirc;m&eacute;? En savoir plus sur la collation des grades, la gestion de carri&egrave;re et les services aux dipl&ocirc;m&eacute;s.</p>
        <h2><a href="http://www.concordia.ca/resources/academic/ask/">Conseiller en ligne</a></h2>
    <p>Vous avez besoin d&rsquo;aide rapidement? Notre conseiller en ligne vous fournit des r&eacute;ponses imm&eacute;diates! Consultez le conseiller en ligne d&egrave;s maintenant.</p>
        <h2><a href="probite-intellectuelle/index.html">Probit&eacute; intellectuelle</a></h2>
    <p>&Agrave; Concordia, c&rsquo;est tol&eacute;rance z&eacute;ro pour la tricherie et le plagiat! Tout contrevenant s&rsquo;expose donc &agrave; de s&eacute;v&egrave;res sanctions et risque notamment l&rsquo;&eacute;chec au cours, voire le renvoi de l&rsquo;Universit&eacute;. L&rsquo;honn&ecirc;tet&eacute; paie : ne prenez pas le plagiat &agrave; la l&eacute;g&egrave;re. 
    En savoir plus sur la probit&eacute; intellectuelle.</p>
<!-- InstanceEndEditable --><br class="hide" />
			</div>

			</div>

		<div class="sidebar">
			<br class="hide" />
<!-- InstanceBeginEditable name="sidebar" --><!-- FCKEDITOR_sidebar --><!-- /FCKEDITOR_sidebar --> <!-- InstanceEndEditable -->

<!-- InstanceBeginEditable name="Sidebar" -->
	


<!-- InstanceEndEditable --><br class="hide" />
    <h2>Voix &eacute;tudiantes</h2>
    <p>Veuillez noter que les sites suivants ne rel&egrave;vent pas de Concordia. Par cons&eacute;quent, l&rsquo;Universit&eacute; n&rsquo;est en aucun cas responsable de leur contenu.</p>
	 
	 <h3>Groupes étudiants</h3>
	<ul>
		<li><a href="http://www.csu.qc.ca/">Concordia Student Union (CSA)</a></li>
		<li><a href="../../../../websitebuildings.concordia.ca/">Graduate Students Alliance (GSA)</a></li>
		<li><a href="http://www.concordia.ca/fr/renseignements-generaux/etudiants-actuels/associations-etudiantes/">Associations étudiantes</a></li>
	</ul>
    
	<h3>Blogues</h3>
	<dl class="normal_list">
		<dt><a href="../../../../websiteconcordiablogs.typepad.com/index.html" rel="outgoing">Blogs@Concordia</a></dt>
		<dd>Liste de blogues d&rsquo;&eacute;tudiants, de professeurs et de dipl&ocirc;m&eacute;s</dd>
	</dl>
   
	 <h3>Sites communautaires</h3>
    <dl class="normal_list">
      <dt><a href="../../../../websitecommunity.livejournal.com/concordia_u/index.html">Concordia_U</a></dt>
		<dd>Plateforme de discussion en ligne entre les nouveaux &eacute;tudiants de Concordia et les &eacute;tudiants potentiels</dd>
    <dt><a href="../../../../websitegroups.myspace.com/index.cfm_fuseaction_groups.groupProfile_groupID_100041448_Mytoken_36B10DD8-2E1D-4450-B9C5F76926FFEE9B281534948">Myspace/ConU</a></dt>
	 <dd>Site non officiel des &eacute;tudiants de Concordia (ouverture de session obligatoire)</dd>
    <!--<dt><a href="http://concordia.facebook.com/">Facebook</a></dt>
	 <dd>En compl&eacute;ment du r&eacute;seau g&eacute;n&eacute;ral de Concordia sur Facebook, une page est destin&eacute;e &agrave; <a href="http://concordia.facebook.com/group.phphttp%3A//www.facebook.com/group.php?gid=2259790637?gid=2259790637">la promotion de 2011</a> (ouverture de session obligatoire)</dd>-->
	 </dl>
	 
    <h3>Journaux et m&eacute;dias</h3>
	 <dl class="normal_list">
	 	<dt><a href="../../../../websitewww.cjlo.com/index.html" rel="outgoing">CJLO</a></dt>
		<dd>Unique station de radio de Concordia. Sans but lucratif, CJLO fonctionne enti&egrave;rement gr&acirc;ce aux b&eacute;n&eacute;voles.</dd>
	 	
		<dt><a href="../../../../websitewww.theconcordian.com/index.html" rel="outgoing">The Concordian</a></dt>
		<dd>Journal &eacute;tudiant ind&eacute;pendant</dd>
	 	
		<dt><a href="http://cutv.concordia.ca/" rel="outgoing">CUTV</a></dt>
		<dd>Cha&icirc;ne &eacute;tudiante de l&rsquo;Universit&eacute; Concordia</dd>
		
		<dt><a href="../../../../websitewww.thelinknewspaper.ca/index.html" rel="outgoing">The Link</a></dt>
		<dd>Journal &eacute;tudiant ind&eacute;pendant</dd>
    </dl>
	<div class="centered"><a href="../../../now/" title="Visitez le site de NOW news and events"><img src="http://www.concordia.ca/imgs/logo-now-small.gif" alt="NOW news and events" /></a></div><br /><h2>Communiqués de presse</h2><div><em class="entry-date">29 Novembre 2011</em></div><p><a href="../../../now/media-relations/communiques-de-presse/20111129/un-etudiant-de-concordia-obtient-une-bourse-rhodes-2012.php">Un étudiant de Concordia obtient une bourse Rhodes 2012 </a></p><div><em class="entry-date">28 Novembre 2011</em></div><p><a href="../../../now/media-relations/communiques-de-presse/20111128/la-depression-augmenterait-le-risque-de-maladie-cardiaque.php">La dépression augmenterait le risque de maladie cardiaque</a></p><div><em class="entry-date">22 Novembre 2011</em></div><p><a href="../../../now/media-relations/communiques-de-presse/20111122/limpact-redoutable-des-mauvaises-habitudes-alimentaires.php">L'impact redoutable des mauvaises habitudes alimentaires </a></p><div><em class="entry-date">17 Novembre 2011</em></div><p><a href="../../../now/media-relations/communiques-de-presse/20111117/presenteisme-travailler-meme-malade.php">Présentéisme: travailler même malade</a></p><div><em class="entry-date">17 Novembre 2011</em></div><p><a href="../../../now/media-relations/communiques-de-presse/20111117/une-anthropologue-judiciaire-et-auteure-un-pionnier-de-laeronautique-et-un-chef-dentreprise-a-lhonne.php">Une anthropologue judiciaire et auteure, un pionnier de l'aéronautique et un chef d'entreprise à l'honneur</a></p><p class="more" style="text-align:right"><a href="../../../now/media-relations/communiques-de-presse/">Plus de communiqu&eacute;s</a></p></div>			</div>

				<div class="clear">&nbsp;</div>
	</div>



	<!-- MAIN CONTENT AREA - END -->


		<div id="announcement">&nbsp;</div>
<h2 class="hide">Concordia University</h2>
<div id="footer">
  <div id="footer_links">
    <h2 class="hide">Tools &amp; Quicklinks</h2>
    <ul style="line-height:1em;"><li><a href="http://www.concordia.ca/fr/index-des-sites.php">Index</a></li>
      <li><a href="http://www.concordia.ca/fr/bottin.php">R&eacute;pertoire</a></li>

      <li><a href="http://www.concordia.ca/fr/concordia-en-bref/nous-situer/carte-des-campus/">Plan du campus</a> </li>
      <li><a href="http://www.concordia.ca/fr/navette.php">Horaire de la navette</a></li>
      <li><a href="http://myconcordia.ca" rel="outgoing">Portail MyConcordia</a></li>
      <li><a href="http://webmail.concordia.ca" rel="outgoing">Courriel Web</a></li>
      <li><a href="http://library.concordia.ca" rel="outgoing">Biblioth&egrave;ques</a></li>

      <li><a href="../../concordia-en-bref/offres-demploi/">Offres d'emploi</a></li>
      <li><a href="../../../index.html" rel="outgoing">Faire un don</a></li>
    </ul>
  </div>
 	<div class="clear">&nbsp;</div>
  <div class="contactinfo"> <a href="../../../index.html"><img src="http://www.concordia.ca/fr/custom/images/common/concordialogo_bottom.gif" alt="Concordia University Logo" /></a>
    <div id="footer_address" class="vcard">
      <p style="margin-bottom: 0"><strong> <span class="fn">Universit&eacute; Concordia</span></strong><br />
        <span class="adr"><span class="street-address">1455, boul. de Maisonneuve Ouest, </span><span class="locality">Montr&eacute;al</span>, <span class="region">Qu&eacute;bec</span>, <span class="country-name">Canada</span> <span class="postal-code">H3G 1M8</span></span><br />
        T&eacute;l&eacute;phone: <span class="tel">(1) 514-848-2424</span><br />
        <a href="http://www.concordia.ca/fr/concordia-en-bref/contactez-nous/" class="url">Contactez-nous</a> | <a href="http://www.concordia.ca/fr/concordia-en-bref/contactez-nous/">Adresse postale de l'universit&eacute;</a> | <a href="http://www.concordia.ca/fr/a-propos-du-site.php">&Agrave; propos de ce site</a><br />
      Copyright &copy; 2011 <span class="org">Universit&eacute; Concordia</span> | <a href="http://www.concordia.ca/fr/avis-juridique.php">Notice l&eacute;gale</a></p>
    </div>
  </div>
  <div id="backtotop">
    <p style="margin-bottom: 0"><a href="http://www.concordia.ca/fr/renseignements-generaux/etudiants-actuels/#top">Haut de page</a></p>
  </div>
  <div class="url">
    <h2>Page Info</h2>
    <p><strong>Page Title</strong>: &Eacute;tudiants actuels - Concordia University - Montreal, Quebec, Canada</p>
    <p><strong>Page URL</strong>:http://www.concordia.ca/fr/renseignements-generaux/etudiants-actuels/index....php </p>
    <p style="margin-bottom: 0;"><strong>Date Printed</strong>: Thu December 1, 2011</p>
  </div>
  <div class="clear">&nbsp;</div>
</div>
<script type="text/javascript">
secure_suffix = "";
domain = "www.concordia.ca";
siteroot = "/fr/";
relative_path = "../../";
data_path = "../../custom/";
</script>
<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try {
/* Concordia Global Tracking Account */
var pageTracker = _gat._getTracker("UA-2729211-1");
pageTracker._setDomainName(".concordia.ca");
pageTracker._trackPageview();
} catch(err) {}</script>
</div>
</body>
<!-- InstanceEnd --></html>
                                                                                                                                                                                                                                            